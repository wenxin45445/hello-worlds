package utils;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 自动生成打包及部署脚本
 * @author Wang.Pang 20170912
 */
public class AutoGenPackageScript {
	
	/**
	 * 程序入口
	 */
	public static void main(String[] args) {
		try {
			// 1. 初始化类和配置
			PackageConfiger configer = new PackageConfiger();
			System.out.println("加载配置信息：");
			System.out.println(configer);
			
			// 2. 对比文件，得出差异文件列表
			Map<String,List<String>> result = getDifferentFile(configer);
			
			
			// 3. 将差异文件复制到一个路径下
			handleDifferentFiles(result);
			
			// 4. 打包差异文件
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public static Map<String,List<String>> getDifferentFile(PackageConfiger configer){
		Map<String,List<String>> result = new HashMap<String,List<String>>();
		File baseFile = new File(configer.getBaseLine());
		File headFile = new File(configer.getHead());
	    for (File subFile : baseFile.listFiles()) {
			
		}
		
		return result;
	}
	
	public static boolean handleDifferentFiles(Map<String,List<String>> differentFiles){
		
		return true;
	}
}
